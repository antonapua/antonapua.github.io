var $ = require("jquery");
$(document).ready(function (){
  // console.log('boop');
});
